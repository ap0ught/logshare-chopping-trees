-- Lumber Vision configuration
-- Changes take effect after restarting the game.

return {
    -- Price, vision range, and active duration for each upgrade level.
    Levels = {
        { Cost = 500.0,  RangeMeters = 25.0, DurationSeconds = 4.0 },
        { Cost = 1500.0, RangeMeters = 50.0, DurationSeconds = 7.0 },
        { Cost = 3000.0, RangeMeters = 80.0, DurationSeconds = 12.0 },
    },

    -- How often highlighted logs and the on-screen timer are refreshed.
    HighlightRefreshMilliseconds = 400,
    StatusRefreshMilliseconds = 200,
    VerboseLogging = false,

    -- Persistent on-screen ACTIVE status and the short READY message.
    ShowStatus = true,
    ShowReadyMessage = true,
    ShowControlHint = true,

    -- Short electronic activation sound from the game.
    EnableActivationSound = true,
    ActivationSound = "/Game/Audio/SFX/Beep/SC_Bip_00.SC_Bip_00",
    ActivationSoundVolume = 0.75,
    ActivationSoundPitch = 1.10,

    -- A short cyan screen pulse used as the activation animation.
    EnableActivationPulse = true,
    PulseOpacity = 0.38,
    PulseDurationSeconds = 0.50,
    PulseColor = { 0.15, 0.80, 1.00, 1.00 },
}
