-- Lumber Vision v0.3.2
-- Client-side visual mod for A Game About Chopping Trees.
-- Standalone perk: it does not depend on Chain Felling or any other upgrade.

local MOD_TAG = "[LumberVision]"
local UEHelpers = require("UEHelpers")

local DEFAULT_CONFIG = {
    Levels = {
        { Cost = 500.0,  RangeMeters = 25.0, DurationSeconds = 4.0 },
        { Cost = 1500.0, RangeMeters = 50.0, DurationSeconds = 7.0 },
        { Cost = 3000.0, RangeMeters = 80.0, DurationSeconds = 12.0 },
    },
    HighlightRefreshMilliseconds = 400,
    StatusRefreshMilliseconds = 200,
    VerboseLogging = false,
    ShowStatus = true,
    ShowReadyMessage = true,
    ShowControlHint = true,
    EnableActivationSound = true,
    ActivationSound = "/Game/Audio/SFX/Beep/SC_Bip_00.SC_Bip_00",
    ActivationSoundVolume = 0.75,
    ActivationSoundPitch = 1.10,
    EnableActivationPulse = true,
    PulseOpacity = 0.38,
    PulseDurationSeconds = 0.50,
    PulseColor = { 0.15, 0.80, 1.00, 1.00 },
}

local config_ok, loaded_config = pcall(require, "LumberVisionConfig")
local CONFIG = config_ok and type(loaded_config) == "table" and loaded_config or DEFAULT_CONFIG
local configured_levels = type(CONFIG.Levels) == "table" and CONFIG.Levels or DEFAULT_CONFIG.Levels
local LEVELS = {}
for index, values in ipairs(configured_levels) do
    local defaults = DEFAULT_CONFIG.Levels[index] or DEFAULT_CONFIG.Levels[#DEFAULT_CONFIG.Levels]
    LEVELS[index] = {
        cost = tonumber(values.Cost) or defaults.Cost,
        range_m = math.max(1.0, tonumber(values.RangeMeters) or defaults.RangeMeters),
        duration_s = math.max(0.25, tonumber(values.DurationSeconds) or defaults.DurationSeconds),
    }
end
if #LEVELS == 0 then
    LEVELS = {
    { cost = 500.0,  range_m = 25.0, duration_s = 4.0 },
    { cost = 1500.0, range_m = 50.0, duration_s = 7.0 },
    { cost = 3000.0, range_m = 80.0, duration_s = 12.0 },
    }
end

local HIGHLIGHT_REFRESH_MS = math.max(
    50,
    math.floor(tonumber(CONFIG.HighlightRefreshMilliseconds)
        or DEFAULT_CONFIG.HighlightRefreshMilliseconds)
)
local STATUS_REFRESH_MS = math.max(
    50,
    math.floor(tonumber(CONFIG.StatusRefreshMilliseconds)
        or DEFAULT_CONFIG.StatusRefreshMilliseconds)
)
local QOL_PATH = "/Game/Blueprints/_Trees_/Tools/Notebook/UI/Upgrades/QOL/DA_Upgrade_QOL.DA_Upgrade_QOL"
local LOG_CAPACITY_PATH = "/Game/Blueprints/_Trees_/Tools/Notebook/UI/Upgrades/LogCapacity/DA_Upgrade_LogsCapacity.DA_Upgrade_LogsCapacity"
local UPGRADE_ITEM_CLASS_PATH = "/Game/Blueprints/_Trees_/Tools/Notebook/UI/BP_UI_UpgradeItem.BP_UI_UpgradeItem_C"
local QOL_ASSET_PATH = "/Game/Blueprints/_Trees_/Tools/Notebook/UI/Upgrades/QOL/DA_Upgrade_QOL"
local LOG_CAPACITY_ASSET_PATH = "/Game/Blueprints/_Trees_/Tools/Notebook/UI/Upgrades/LogCapacity/DA_Upgrade_LogsCapacity"
local UPGRADE_ITEM_ASSET_PATH = "/Game/Blueprints/_Trees_/Tools/Notebook/UI/BP_UI_UpgradeItem"
local ACTION_HELPER_ASSET_PATH = "/Game/UI/HUD/HelpActions/W_ActionHelper"
local ACTION_HELPER_CLASS_PATH = "/Game/UI/HUD/HelpActions/W_ActionHelper.W_ActionHelper_C"
local LUMBER_ACTION_ASSET_PATH = "/Game/Blueprints/Player/Input/Actions/IA_Ability_1"
local LUMBER_ACTION_PATH = "/Game/Blueprints/Player/Input/Actions/IA_Ability_1.IA_Ability_1"
local CONTROLLER_HINT_ACTION_ASSET_PATH = "/Game/Blueprints/Player/Input/Actions/IA_RMB"
local CONTROLLER_HINT_ACTION_PATH = "/Game/Blueprints/Player/Input/Actions/IA_RMB.IA_RMB"

local enabled = false
local highlighted = {}
local known_logs = {}
local log_cache_initialized = false
local outliner = nil
local player = nil
local primitive_component_class = nil
local lumber_definition = nil
local lumber_item = nil
local current_range_m = 0.0
local active_until = 0.0
local end_handle = nil
local refresh_handle = nil
local status_handle = nil
local hint_input_handle = nil
local input_latched = false
local last_game_time = nil
local activation_sound = nil
local help_extension_handle = nil
local help_widget = nil
local keyboard_hint_action = nil
local controller_hint_action = nil
local current_hint_uses_gamepad = nil

local function is_valid(object)
    if not object then
        return false
    end
    local ok, result = pcall(function()
        return object:IsValid()
    end)
    return ok and result
end

local function object_name(object)
    if not is_valid(object) then
        return "<invalid>"
    end
    local ok, result = pcall(function()
        return object:GetFullName()
    end)
    return ok and result or "<name-error>"
end

local function class_name(object)
    if not is_valid(object) then
        return ""
    end
    local ok, result = pcall(function()
        return object:GetClass():GetFName():ToString()
    end)
    return ok and result or ""
end

local function is_ground_log(actor)
    local name = class_name(actor)
    return string.sub(name, 1, 11) == "BP_Tree_Log"
        or name == "BP_Tree_FallenLog_C"
end

local function find_player()
    if is_valid(player) then
        return player
    end
    local candidates = FindAllOf("BP_Human_C")
    if candidates then
        for _, candidate in ipairs(candidates) do
            if is_valid(candidate) then
                player = candidate
                return player
            end
        end
    end
    return nil
end

local function game_time_seconds()
    local human = find_player()
    if human then
        local ok, result = pcall(function()
            return UEHelpers.GetKismetSystemLibrary():GetGameTimeInSeconds(human)
        end)
        if ok and type(result) == "number" then
            -- Unreal resets this clock when returning to the main menu and
            -- loading the save again. Discard transient vision state.
            if last_game_time and result + 0.5 < last_game_time then
                active_until = 0.0
                enabled = false
                highlighted = {}
                print(string.format("%s World clock reset detected; transient state cleared.\n", MOD_TAG))
            end
            last_game_time = result
            return result
        end
    end
    return os.clock()
end

local function get_xyz(vector)
    if not vector then
        return nil
    end
    local ok, x, y, z = pcall(function()
        return vector.X, vector.Y, vector.Z
    end)
    if ok and type(x) == "number" and type(y) == "number" and type(z) == "number" then
        return x, y, z
    end
    return nil
end

local function distance_to_player_m(actor)
    local human = find_player()
    if not human or not is_valid(actor) then
        return math.huge
    end
    local ok, actor_location, player_location = pcall(function()
        return actor:K2_GetActorLocation(), human:K2_GetActorLocation()
    end)
    if not ok then
        return math.huge
    end
    local ax, ay, az = get_xyz(actor_location)
    local px, py, pz = get_xyz(player_location)
    if not ax or not px then
        return math.huge
    end
    local dx, dy, dz = ax - px, ay - py, az - pz
    return math.sqrt(dx * dx + dy * dy + dz * dz) / 100.0
end

local function find_upgrade_component()
    local human = find_player()
    if human then
        for _, property_name in ipairs({ "TreesUpgradeComponent", "TreesUpgrade" }) do
            local ok, component = pcall(function()
                return human:GetPropertyValue(property_name)
            end)
            if ok and is_valid(component) then
                return component
            end
        end
    end

    local candidates = FindAllOf("TreesUpgradeComponent")
    if candidates then
        for _, component in ipairs(candidates) do
            if is_valid(component) then
                local ok, owner = pcall(function()
                    return component:GetOwner()
                end)
                if not human or (ok and is_valid(owner) and owner:GetAddress() == human:GetAddress()) then
                    return component
                end
            end
        end
    end
    return nil
end

local function get_lumber_level()
    if not is_valid(lumber_definition) then
        return 0
    end
    local component = find_upgrade_component()
    if not component then
        return 0
    end
    local ok, level = pcall(function()
        return component:GetCurrentLevel(lumber_definition)
    end)
    if ok and type(level) == "number" then
        return math.max(0, math.min(#LEVELS, math.floor(level)))
    end
    return 0
end

local function show_message(message, kind)
    print(string.format("%s %s\n", MOD_TAG, message))
    local world_context = find_player()
    if not world_context then
        return
    end

    -- Presentation only. Failure here never affects mod logic.
    pcall(function()
        local color = { 0.20, 0.85, 1.00, 1.00 }
        if kind == "locked" then
            color = { 1.00, 0.62, 0.15, 1.00 }
        elseif kind == "enabled" then
            color = { 0.30, 1.00, 0.35, 1.00 }
        end
        UEHelpers.GetKismetSystemLibrary():PrintString(
            world_context,
            message,
            true,
            false,
            color,
            5.0,
            FName("GroundLogHighlighter")
        )
    end)
end

local function draw_status(message, kind, duration)
    if CONFIG.ShowStatus == false then
        return
    end
    local world_context = find_player()
    if not world_context then
        return
    end
    pcall(function()
        local color = { 0.20, 0.85, 1.00, 1.00 }
        if kind == "active" then
            color = { 0.30, 1.00, 0.35, 1.00 }
        elseif kind == "ready" then
            color = { 0.20, 0.85, 1.00, 1.00 }
        end
        UEHelpers.GetKismetSystemLibrary():PrintString(
            world_context,
            message,
            true,
            false,
            color,
            duration or (STATUS_REFRESH_MS / 1000.0 + 0.15),
            FName("LumberVisionStatus")
        )
    end)
end

local function find_outliner()
    if is_valid(outliner) then
        return outliner
    end
    local human = find_player()
    if human then
        local ok, component = pcall(function()
            return human:GetPropertyValue("AC_Outliner_Advanced")
        end)
        if ok and is_valid(component) then
            outliner = component
            print(string.format("%s Using player outliner: %s\n", MOD_TAG, component:GetFullName()))
            return outliner
        end
    end

    local candidates = FindAllOf("AC_Outliner_Advanced_C")
    if candidates then
        for _, candidate in ipairs(candidates) do
            if is_valid(candidate) then
                outliner = candidate
                print(string.format("%s Using native outliner: %s\n", MOD_TAG, candidate:GetFullName()))
                return outliner
            end
        end
    end
    return nil
end

local function call_native_outliner(actor, should_enable)
    local component = find_outliner()
    if not component then
        return false, "AC_Outliner_Advanced_C instance not found"
    end

    local function invoke(function_name)
        local ok, result = pcall(function()
            local fn = component[function_name]
            if not fn then
                error("function not found")
            end
            -- Parameters: actor, behaviour, enable, type.
            -- Behaviour 1 = all primitive components; type 0 = Primary.
            fn(component, actor, 1, should_enable, 0)
            return true
        end)
        return ok and result
    end

    if invoke("Switch Outline On Actor") then
        return true
    end
    if invoke("Client: Switch Outline on actor") then
        return true
    end
    return false, "native outline function was unavailable"
end

local function apply_custom_depth(actor, should_enable)
    if not primitive_component_class then
        primitive_component_class = StaticFindObject("/Script/Engine.PrimitiveComponent")
    end
    if not is_valid(primitive_component_class) then
        return false, "PrimitiveComponent class not found"
    end

    local ok, components = pcall(function()
        return actor:K2_GetComponentsByClass(primitive_component_class)
    end)
    if not ok or not components then
        return false, "K2_GetComponentsByClass failed"
    end

    local changed = 0
    for _, component in ipairs(components) do
        if is_valid(component) then
            local changed_ok = pcall(function()
                component:SetCustomDepthStencilValue(1)
                component:SetRenderCustomDepth(should_enable)
            end)
            if changed_ok then
                changed = changed + 1
            end
        end
    end
    return changed > 0, string.format("custom depth changed on %d components", changed)
end

local function set_highlight(actor, should_enable)
    if not is_ground_log(actor) then
        return false
    end
    local address = actor:GetAddress()
    if should_enable and highlighted[address] then
        return true
    end
    if not should_enable and not highlighted[address] then
        return true
    end

    local success, native_info = call_native_outliner(actor, should_enable)
    local fallback_info = "not needed"
    if not success then
        success, fallback_info = apply_custom_depth(actor, should_enable)
    end

    if success and should_enable then
        highlighted[address] = true
    elseif success then
        highlighted[address] = nil
    end

    if not success then
        print(string.format(
            "%s Failed actor=%s native=%s fallback=%s\n",
            MOD_TAG,
            actor:GetFullName(),
            tostring(native_info),
            tostring(fallback_info)
        ))
    end
    return success
end

local function rebuild_log_cache()
    known_logs = {}
    local actors = FindAllOf("Actor")
    if actors then
        for _, actor in ipairs(actors) do
            if is_valid(actor) and is_ground_log(actor) then
                known_logs[actor:GetAddress()] = actor
            end
        end
    end
    log_cache_initialized = true
end

local function refresh_all(rescan)
    if rescan or not log_cache_initialized then
        rebuild_log_cache()
    end
    local found = 0
    local changed = 0
    for address, actor in pairs(known_logs) do
        if is_valid(actor) then
            found = found + 1
            local should_highlight = enabled
                and distance_to_player_m(actor) <= current_range_m
            local is_highlighted = highlighted[address] == true
            if should_highlight ~= is_highlighted then
                if set_highlight(actor, should_highlight) then
                    changed = changed + 1
                end
            end
        else
            known_logs[address] = nil
            highlighted[address] = nil
        end
    end
    if not enabled then
        highlighted = {}
    end
    if CONFIG.VerboseLogging == true then
        print(string.format(
            "%s Refresh complete: enabled=%s logs=%d changed=%d\n",
            MOD_TAG,
            tostring(enabled),
            found,
            changed
        ))
    end
end

local function make_text(value)
    local ok, result = pcall(function()
        return UEHelpers.GetKismetTextLibrary():Conv_StringToText(value)
    end)
    return ok and result or value
end

local function clear_step_effects(step, level_data)
    step.StepDescription = make_text(string.format(
        "RANGE: %dm  |  DURATION: %ds",
        level_data.range_m,
        level_data.duration_s
    ))
    step.Cost = level_data.cost
    step.CostCalculator = nil
    step.UpgradeEffect = nil
    step.bSharedStep = false
    step.StepUnlockChecker = nil
    step.CustomStep = nil
    pcall(function()
        step.TextParams:Empty()
    end)
    pcall(function()
        step.AdditionalCustomSteps:Empty()
    end)
end

local function ensure_step_count(steps, desired_count)
    local current_count = steps:GetArrayNum()
    if current_count == desired_count then
        return
    end

    if current_count < 1 then
        error("upgrade template has no steps to clone")
    end

    -- UE4SS uses zero-based offsets for TArray values. Assigning just past
    -- the last element grows the array and copies the source struct.
    while current_count < desired_count do
        steps[current_count] = steps[current_count - 1]
        local new_count = steps:GetArrayNum()
        if new_count <= current_count then
            error(string.format(
                "could not grow the upgrade steps array (%d/%d)",
                new_count,
                desired_count
            ))
        end
        current_count = new_count
    end

    if current_count > desired_count then
        local array_library = StaticFindObject("/Script/Engine.Default__KismetArrayLibrary")
        if not is_valid(array_library) then
            error("KismetArrayLibrary is unavailable for step resizing")
        end
        array_library:Array_Resize(steps, desired_count)
        current_count = steps:GetArrayNum()
    end

    if current_count ~= desired_count then
        error(string.format(
            "upgrade step resize ended at %d; expected %d",
            current_count,
            desired_count
        ))
    end
end

local function ensure_lumber_definition()
    if is_valid(lumber_definition) and is_valid(lumber_item) then
        return true
    end

    local qol = StaticFindObject(QOL_PATH)
    if not is_valid(qol) then
        -- The shop normally loads these only when it is opened. Loading them
        -- here makes the saved Lumber Vision level available to Q / LT as soon
        -- as the gameplay world starts.
        pcall(function() LoadAsset(QOL_ASSET_PATH) end)
        pcall(function() LoadAsset(LOG_CAPACITY_ASSET_PATH) end)
        pcall(function() LoadAsset(UPGRADE_ITEM_ASSET_PATH) end)
        qol = StaticFindObject(QOL_PATH)
        if not is_valid(qol) then
            print(string.format("%s Waiting for the upgrade assets to load.\n", MOD_TAG))
            return false
        end
    end

    local definition = nil
    local item = nil
    local ok, setup_error = pcall(function()
        local outer = qol:GetOuter()
        local existing_definition = StaticFindObject(
            "/Game/Blueprints/_Trees_/Tools/Notebook/UI/Upgrades/QOL/DA_Upgrade_QOL.DA_Upgrade_LumberVision"
        )
        definition = existing_definition
        if not is_valid(definition) then
            definition = StaticConstructObject(
                qol:GetClass(),
                outer,
                FName("DA_Upgrade_LumberVision"),
                0,
                0,
                false,
                false,
                qol,
                nil,
                nil,
                nil
            )
        end
        if not is_valid(definition) then
            error("could not construct Lumber Vision definition")
        end

        definition:SetPropertyValue("UpgradeName", make_text("Lumber Vision"))
        definition:SetPropertyValue("AvailabilityChecker", nil)
        definition:SetPropertyValue("AvailabilityHint", make_text(""))
        definition:SetPropertyValue("UnlockChecker", nil)
        definition:SetPropertyValue("bIsOneTimeAction", false)

        local log_capacity = StaticFindObject(LOG_CAPACITY_PATH)
        if is_valid(log_capacity) then
            definition:SetPropertyValue("Icon", log_capacity:GetPropertyValue("Icon"))
        end

        local steps = definition:GetPropertyValue("Steps")
        ensure_step_count(steps, #LEVELS)
        local step_count = 0
        steps:ForEach(function(index, element)
            local level_data = LEVELS[index]
            if level_data then
                clear_step_effects(element:get(), level_data)
                step_count = step_count + 1
            end
        end)
        if step_count ~= #LEVELS then
            error(string.format("template has %d steps; expected %d", step_count, #LEVELS))
        end

        local item_class = StaticFindObject(UPGRADE_ITEM_CLASS_PATH)
        if not is_valid(item_class) then
            pcall(function() LoadAsset(UPGRADE_ITEM_ASSET_PATH) end)
            item_class = StaticFindObject(UPGRADE_ITEM_CLASS_PATH)
        end
        if not is_valid(item_class) then
            error("BP_UI_UpgradeItem_C is not loaded")
        end
        local existing_item = StaticFindObject(
            "/Game/Blueprints/_Trees_/Tools/Notebook/UI/Upgrades/QOL/DA_Upgrade_QOL.BP_UI_LumberVision"
        )
        item = existing_item
        if not is_valid(item) then
            item = StaticConstructObject(
                item_class,
                outer,
                FName("BP_UI_LumberVision"),
                0,
                0,
                false,
                false,
                nil,
                nil,
                nil,
                nil
            )
        end
        if not is_valid(item) then
            error("could not construct Lumber Vision shop item")
        end
        item:SetPropertyValue("UpgradeDefinition", definition)
    end)

    if not ok or not is_valid(definition) or not is_valid(item) then
        print(string.format("%s Definition setup failed: %s\n", MOD_TAG, tostring(setup_error)))
        return false
    end

    lumber_definition = definition
    lumber_item = item
    print(string.format("%s Created standalone definition: %s\n", MOD_TAG, object_name(definition)))
    return true
end

local function inject_lumber_item(shop)
    if not is_valid(shop) or not ensure_lumber_definition() then
        return false
    end
    local ok, result = pcall(function()
        local definitions = shop:GetPropertyValue("UpgradesDefinitions")
        if not definitions then
            error("UpgradesDefinitions array is unavailable")
        end

        local definition_path = object_name(lumber_definition)
        local definition_is_registered = false
        definitions:ForEach(function(_, element)
            local existing_definition = element:get()
            if is_valid(existing_definition)
                and object_name(existing_definition) == definition_path then
                definition_is_registered = true
                return true
            end
        end)

        if not definition_is_registered then
            local old_count = definitions:GetArrayNum()
            -- UE4SS exposes these UObject-array assignments with one-based
            -- indexing, so the append slot is old_count + 1.
            definitions[old_count + 1] = lumber_definition
            local new_count = definitions:GetArrayNum()
            if new_count ~= old_count + 1 then
                error(string.format(
                    "could not register the definition with the shop (%d -> %d)",
                    old_count,
                    new_count
                ))
            end
            print(string.format(
                "%s Registered Lumber Vision in the shop source list (%d definitions).\n",
                MOD_TAG,
                new_count
            ))
        end

        local upgrades = shop:GetPropertyValue("Upgrades")
        if not is_valid(upgrades) then
            error("Upgrades ListView is not valid")
        end

        local item_is_present = false
        pcall(function()
            local list_items = upgrades:GetListItems()
            list_items:ForEach(function(_, element)
                local existing_item = element:get()
                if is_valid(existing_item) then
                    local existing_definition = existing_item:GetPropertyValue("UpgradeDefinition")
                    if is_valid(existing_definition)
                        and object_name(existing_definition) == definition_path then
                        item_is_present = true
                        return true
                    end
                end
            end)
        end)

        if not item_is_present then
            upgrades:AddItem(lumber_item)
        end
        return true
    end)
    print(string.format("%s Shop row injection: %s (%s)\n", MOD_TAG, tostring(ok and result), tostring(result)))
    return ok and result
end

local function schedule_shop_injection(shop, attempt)
    local attempt_number = attempt or 1
    local delay_ms = attempt_number == 1 and 25 or 100
    ExecuteInGameThreadWithDelay(delay_ms, function()
        if not is_valid(shop) then
            return
        end
        if inject_lumber_item(shop) then
            print(string.format(
                "%s Shop ready after %d injection attempt(s).\n",
                MOD_TAG,
                attempt_number
            ))
            return
        end
        if attempt_number < 20 then
            schedule_shop_injection(shop, attempt_number + 1)
        else
            print(string.format("%s Shop injection timed out.\n", MOD_TAG))
        end
    end)
end

NotifyOnNewObject(
    "/Game/Blueprints/_Trees_/Tools/Notebook/UI/W_Trees_Shop.W_Trees_Shop_C",
    function(shop)
        schedule_shop_injection(shop, 1)
    end
)

local function play_activation_feedback()
    local human = find_player()
    if not human then
        return
    end

    local sound_played = false
    if CONFIG.EnableActivationSound ~= false then
        local sound_path = tostring(CONFIG.ActivationSound or DEFAULT_CONFIG.ActivationSound)
        if not is_valid(activation_sound) then
            activation_sound = StaticFindObject(sound_path)
            if not is_valid(activation_sound) then
                local package_path = string.gsub(sound_path, "%.[^./]+$", "")
                pcall(function() LoadAsset(package_path) end)
                activation_sound = StaticFindObject(sound_path)
            end
        end
        if is_valid(activation_sound) then
            sound_played = pcall(function()
                UEHelpers.GetGameplayStatics():PlaySound2D(
                    human,
                    activation_sound,
                    tonumber(CONFIG.ActivationSoundVolume)
                        or DEFAULT_CONFIG.ActivationSoundVolume,
                    tonumber(CONFIG.ActivationSoundPitch)
                        or DEFAULT_CONFIG.ActivationSoundPitch,
                    0.0,
                    nil,
                    nil,
                    true
                )
            end)
        end
    end

    local pulse_played = false
    if CONFIG.EnableActivationPulse ~= false then
        pulse_played = pcall(function()
            local controller = UEHelpers.GetPlayerController()
            if not is_valid(controller) then
                error("player controller unavailable")
            end
            local camera_manager = controller:GetPropertyValue("PlayerCameraManager")
            if not is_valid(camera_manager) then
                error("camera manager unavailable")
            end
            local opacity = math.max(0.0, math.min(
                1.0,
                tonumber(CONFIG.PulseOpacity) or DEFAULT_CONFIG.PulseOpacity
            ))
            local duration = math.max(
                0.10,
                tonumber(CONFIG.PulseDurationSeconds)
                    or DEFAULT_CONFIG.PulseDurationSeconds
            )
            local color = CONFIG.PulseColor or DEFAULT_CONFIG.PulseColor
            local fade_in = math.min(0.15, duration * 0.35)
            local fade_out = math.max(0.05, duration - fade_in)
            camera_manager:StartCameraFade(
                0.0,
                opacity,
                fade_in,
                color,
                false,
                true
            )
            ExecuteInGameThreadWithDelay(math.floor(fade_in * 1000), function()
                if is_valid(camera_manager) then
                    camera_manager:StartCameraFade(
                        opacity,
                        0.0,
                        fade_out,
                        color,
                        false,
                        false
                    )
                end
            end)
        end)
    end

    print(string.format(
        "%s Activation feedback: sound=%s pulse=%s\n",
        MOD_TAG,
        tostring(sound_played),
        tostring(pulse_played)
    ))
end

local function find_lumber_input_action()
    if not is_valid(keyboard_hint_action) then
        pcall(function() LoadAsset(LUMBER_ACTION_ASSET_PATH) end)
        keyboard_hint_action = StaticFindObject(LUMBER_ACTION_PATH)
    end
    return is_valid(keyboard_hint_action) and keyboard_hint_action or nil
end

local function find_controller_hint_action()
    if not is_valid(controller_hint_action) then
        pcall(function() LoadAsset(CONTROLLER_HINT_ACTION_ASSET_PATH) end)
        controller_hint_action = StaticFindObject(CONTROLLER_HINT_ACTION_PATH)
    end
    return is_valid(controller_hint_action) and controller_hint_action or nil
end

local function find_help_widget()
    if is_valid(help_widget) then
        return help_widget
    end
    local candidates = FindAllOf("W_ActionHelper_C")
    if candidates then
        for _, candidate in ipairs(candidates) do
            if is_valid(candidate)
                and class_name(candidate) == "W_ActionHelper_C"
                and not string.find(object_name(candidate), "Default__", 1, true) then
                help_widget = candidate
                return help_widget
            end
        end
    end
    return nil
end

local function set_help_text(value)
    local widget = find_help_widget()
    if not widget then
        return false
    end
    local ok = pcall(function()
        local text = make_text(value)
        widget:SetPropertyValue("Text", text)
        local text_block = widget:GetPropertyValue("HelpText")
        if is_valid(text_block) then
            text_block:SetText(text)
        end
    end)
    return ok
end

local function set_help_input_action(use_gamepad)
    if current_hint_uses_gamepad == use_gamepad then
        return true
    end
    local widget = find_help_widget()
    if not widget then
        return false
    end
    local input_action = use_gamepad
        and find_controller_hint_action()
        or find_lumber_input_action()
    if not is_valid(input_action) then
        return false
    end
    local ok = pcall(function()
        widget:SetPropertyValue("Enhanced Input Action", input_action)
        local action_widget = widget:GetPropertyValue("ActionWidget")
        if is_valid(action_widget) then
            action_widget:SetEnhancedInputAction(input_action)
        end
    end)
    if ok then
        current_hint_uses_gamepad = use_gamepad
    end
    return ok
end

local function update_help_input_action()
    if not is_valid(help_widget) then
        find_help_widget()
    end
    local use_gamepad = false
    local detected = pcall(function()
        local subsystem_library = StaticFindObject(
            "/Script/Engine.Default__SubsystemBlueprintLibrary"
        )
        local subsystem_class = StaticFindObject(
            "/Script/CommonInput.CommonInputSubsystem"
        )
        local controller = UEHelpers.GetPlayerController()
        local subsystem = subsystem_library:GetLocalPlayerSubSystemFromPlayerController(
            controller,
            subsystem_class
        )
        local input_type = subsystem:GetCurrentInputType()
        local numeric_type = tonumber(input_type)
        use_gamepad = numeric_type == 1
            or string.find(tostring(input_type), "Gamepad", 1, true) ~= nil
    end)
    if detected then
        set_help_input_action(use_gamepad)
    end
end

local function schedule_help_widget_bind(value, attempt)
    local attempt_number = attempt or 1
    ExecuteInGameThreadWithDelay(250, function()
        if set_help_text(value) then
            print(string.format(
                "%s Control hint widget bound after %d attempt(s).\n",
                MOD_TAG,
                attempt_number
            ))
        elseif attempt_number < 20 and is_valid(player) then
            schedule_help_widget_bind(value, attempt_number + 1)
        else
            print(string.format("%s Control hint widget was not created.\n", MOD_TAG))
        end
    end)
end

local function register_control_hint()
    if CONFIG.ShowControlHint == false then
        return true
    end

    local ok, result = pcall(function()
        pcall(function() LoadAsset(ACTION_HELPER_ASSET_PATH) end)
        local helper_class = StaticFindObject(ACTION_HELPER_CLASS_PATH)
        if not is_valid(helper_class) then
            error("W_ActionHelper_C is unavailable")
        end
        local input_action = find_lumber_input_action()
        if not is_valid(input_action) then
            error("could not load the keyboard hint action for Q / LT")
        end

        local helper_cdo = helper_class:GetCDO()
        helper_cdo:SetPropertyValue("Text", make_text("Lumber Vision"))
        helper_cdo:SetPropertyValue("Enhanced Input Action", input_action)

        local subsystem_library = StaticFindObject(
            "/Script/Engine.Default__SubsystemBlueprintLibrary"
        )
        local subsystem_class = StaticFindObject(
            "/Script/UIExtension.UIExtensionSubsystem"
        )
        if not is_valid(subsystem_library) or not is_valid(subsystem_class) then
            error("UI extension subsystem is unavailable")
        end

        local subsystem = subsystem_library:GetWorldSubsystem(find_player(), subsystem_class)
        if not is_valid(subsystem) then
            error("could not obtain the UI extension subsystem")
        end

        help_extension_handle = subsystem:K2_RegisterExtensionAsWidget(
            { TagName = FName("UI.Extension.ActionList") },
            helper_class,
            100
        )
        schedule_help_widget_bind("Lumber Vision", 1)
        return true
    end)

    print(string.format(
        "%s Control hint registration: %s (%s)\n",
        MOD_TAG,
        tostring(ok and result),
        tostring(result)
    ))
    return ok and result
end

RegisterBeginPlayPostHook(function(actor_param)
    local ok, actor = pcall(function()
        return actor_param:Get()
    end)
    if not ok or not is_valid(actor) then
        return
    end

    if class_name(actor) == "BP_Human_C" then
        enabled = false
        highlighted = {}
        known_logs = {}
        log_cache_initialized = false
        current_range_m = 0.0
        active_until = 0.0
        last_game_time = nil
        input_latched = false
        if refresh_handle and IsValidDelayedActionHandle(refresh_handle) then
            CancelDelayedAction(refresh_handle)
        end
        refresh_handle = nil
        if end_handle and IsValidDelayedActionHandle(end_handle) then
            CancelDelayedAction(end_handle)
        end
        end_handle = nil
        if status_handle and IsValidDelayedActionHandle(status_handle) then
            CancelDelayedAction(status_handle)
        end
        status_handle = nil
        if hint_input_handle and IsValidDelayedActionHandle(hint_input_handle) then
            CancelDelayedAction(hint_input_handle)
        end
        hint_input_handle = nil
        help_extension_handle = nil
        help_widget = nil
        current_hint_uses_gamepad = nil
        player = actor
        outliner = nil
        print(string.format("%s New player world detected; runtime state reset.\n", MOD_TAG))
        ExecuteInGameThreadWithDelay(250, function()
            if is_valid(player) and ensure_lumber_definition() then
                print(string.format(
                    "%s Saved upgrade level ready at world start: %d\n",
                    MOD_TAG,
                    get_lumber_level()
                ))
            end
        end)
        ExecuteInGameThreadWithDelay(500, function()
            if is_valid(player) then
                register_control_hint()
                hint_input_handle = LoopInGameThreadWithDelay(500, function()
                    update_help_input_action()
                end)
            end
        end)
        return
    end
    if is_ground_log(actor) then
        known_logs[actor:GetAddress()] = actor
        if enabled and distance_to_player_m(actor) <= current_range_m then
            set_highlight(actor, true)
        end
    end
end)

local function stop_status_updates()
    if status_handle and IsValidDelayedActionHandle(status_handle) then
        CancelDelayedAction(status_handle)
    end
    status_handle = nil
end

local function update_active_status()
    if not enabled then
        return
    end
    if CONFIG.ShowStatus == false then
        set_help_text("Lumber Vision")
        return
    end
    local remaining = math.max(0.0, active_until - game_time_seconds())
    local message = string.format(
        "Lumber Vision  ACTIVE  %.1fs  |  %dm",
        remaining,
        math.floor(current_range_m)
    )
    if not set_help_text(message) then
        draw_status(message, "active")
    end
end

local function start_status_updates()
    stop_status_updates()
    update_active_status()
    status_handle = LoopInGameThreadWithDelay(STATUS_REFRESH_MS, function()
        update_active_status()
    end)
end

local function stop_lumber_vision()
    enabled = false
    current_range_m = 0.0
    active_until = 0.0
    if refresh_handle and IsValidDelayedActionHandle(refresh_handle) then
        CancelDelayedAction(refresh_handle)
    end
    refresh_handle = nil
    refresh_all(false)
    stop_status_updates()
    print(string.format("%s Lumber Vision ended; ready immediately.\n", MOD_TAG))
    set_help_text("Lumber Vision  READY")
    ExecuteInGameThreadWithDelay(2500, function()
        if not enabled then
            set_help_text("Lumber Vision")
        end
    end)
    if CONFIG.ShowReadyMessage ~= false then
        draw_status("LUMBER VISION  READY  |  Q / LT", "ready", 2.5)
    end
end

local function activate_lumber_vision()
    if not is_valid(lumber_definition) then
        ensure_lumber_definition()
    end
    local level = get_lumber_level()
    if level <= 0 then
        show_message("Lumber Vision is locked - buy it in Upgrades", "locked")
        return
    end

    local now = game_time_seconds()
    if enabled then
        show_message("Lumber Vision is already active", "normal")
        return
    end
    local level_data = LEVELS[level]
    enabled = true
    current_range_m = level_data.range_m
    active_until = now + level_data.duration_s
    refresh_all(true)

    if refresh_handle and IsValidDelayedActionHandle(refresh_handle) then
        CancelDelayedAction(refresh_handle)
    end
    refresh_handle = LoopInGameThreadWithDelay(HIGHLIGHT_REFRESH_MS, function()
        if enabled then
            refresh_all(false)
        end
    end)

    if end_handle and IsValidDelayedActionHandle(end_handle) then
        CancelDelayedAction(end_handle)
    end
    end_handle = ExecuteInGameThreadWithDelay(math.floor(level_data.duration_s * 1000), function()
        stop_lumber_vision()
    end)

    play_activation_feedback()
    start_status_updates()
    print(string.format(
        "%s Lumber Vision Lv.%d - %dm for %ss\n",
        MOD_TAG,
        level,
        level_data.range_m,
        tostring(level_data.duration_s)
    ))
end

local keyboard_key = { KeyName = FName("Q") }
local controller_key = { KeyName = FName("Gamepad_LeftTriggerAxis") }
LoopInGameThreadWithDelay(25, function()
    local controller = UEHelpers.GetPlayerController()
    if not is_valid(controller) then
        input_latched = false
        return
    end
    local keyboard_pressed = false
    local controller_pressed = false
    local ok, pressed = pcall(function()
        keyboard_pressed = controller:IsInputKeyDown(keyboard_key)
        controller_pressed = controller:IsInputKeyDown(controller_key)
        return keyboard_pressed or controller_pressed
    end)
    if ok and pressed and not input_latched then
        input_latched = true
        set_help_input_action(controller_pressed)
        activate_lumber_vision()
    elseif not ok or not pressed then
        input_latched = false
    end
end)

print(string.format(
    "%s v0.3.2 loaded. Q / Gamepad LT, no cooldown, cached scan, config=%s, levels=%d.\n",
    MOD_TAG,
    tostring(config_ok),
    #LEVELS
))
