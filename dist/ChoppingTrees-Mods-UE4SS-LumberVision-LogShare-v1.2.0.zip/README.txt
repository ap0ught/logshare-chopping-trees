UE4SS + Lumber Vision + LogShare — A Game About Chopping Trees (merged package)
Package version: 1.2.0 (merged, three mods)
Contents: UE4SS package v1.0.0 + Lumber Vision v0.3.2 + LogShare v0.1.0

WHAT'S INSIDE
1. UE4SS v3.0.1-1133-gb4cefa18 — Lua mod loader configured for this game
   (Steam App 4512570, Unreal Engine 5.7 / Windows 64-bit).
2. Lumber Vision v0.3.2 (Kaliraxa) — purchasable perk that highlights chopped
   logs on the ground (three levels: $500/25m/4s, $1,500/50m/7s, $3,000/80m/12s).
   Enabled by default (enabled.txt ships with the mod).
3. LogShare v0.1.0 — co-op log ownership split:
   - Each chopped log is tagged with the chopper's player id.
   - When a log is sold: if the seller also chopped it, they get full price.
   - If someone else chopped it, the seller keeps half and the chopper
     receives the other half (configurable via ChopperShare).
   Enabled by default. Both co-op players should run it for consistent tags.

INSTALLATION
1. In Steam, right-click the game and select Manage > Browse local files.
2. Open ChoppingTrees\Binaries\Win64.
3. Extract this archive directly into that Win64 folder.
4. Confirm that dwmapi.dll is beside ChoppingTrees-Win64-Shipping.exe and that
   these exist:
     ue4ss\Mods\LumberVision\Scripts\main.lua
     ue4ss\Mods\LogShare\Scripts\main.lua
5. Launch the game normally. No extra enable step: both mods ship enabled.txt.

EXPECTED LAYOUT
ChoppingTrees\Binaries\Win64\dwmapi.dll
ChoppingTrees\Binaries\Win64\ue4ss\UE4SS.dll
ChoppingTrees\Binaries\Win64\ue4ss\UE4SS-settings.ini
ChoppingTrees\Binaries\Win64\ue4ss\Mods\LumberVision\Scripts\main.lua
ChoppingTrees\Binaries\Win64\ue4ss\Mods\LumberVision\Scripts\LumberVisionConfig.lua
ChoppingTrees\Binaries\Win64\ue4ss\Mods\LogShare\Scripts\main.lua
ChoppingTrees\Binaries\Win64\ue4ss\Mods\LogShare\Scripts\LogShareConfig.lua

LUMBER VISION CONTROLS
- Keyboard: Q
- Controller: LT / Left Trigger

CONFIGURATION
- Lumber Vision: ue4ss\Mods\LumberVision\Scripts\LumberVisionConfig.lua
  (costs, range, duration, display, sound, pulse).
- LogShare: ue4ss\Mods\LogShare\Scripts\LogShareConfig.lua
  (ChopperShare fraction, verbose logging, owner-property writes, toasts).
Restart the game after editing either config.

LOGSHARE NOTES (v0.1.0)
- Solo play is unaffected (seller always == chopper -> full price).
- Splits are applied by adjusting the Money attribute on each PlayerState.
  If the other player's PlayerState is not visible on your client, the split
  is logged but not delivered — run the mod on both clients.
- Ownership tags come from spawn watchers on BP_Tree_Log* plus a world scan;
  logs that already carry LogOwnerId are respected.
- Verbose logging writes to the UE4SS console/log; use it to confirm splits.
- Multiplayer is experimental; verify with a small test batch first.

UNINSTALLATION
- Remove dwmapi.dll and the ue4ss folder to remove everything.
- Or delete only ue4ss\Mods\LogShare and/or ue4ss\Mods\LumberVision to keep
  UE4SS with a subset. Neither modifies save files.

NOTES
- Player-focused UE4SS config: developer consoles and automatic Lua hot reload are disabled.
- UE4SS binaries are unchanged from the official build; only configuration is game-specific.
- This package contains no game files, save files, or logs.
- If Steam updates or verifies the game, reinstall this package if necessary.
- Lumber Vision: tested with game version 1.1.0.4; client-side visual mod.
- LogShare: first release; co-op money split is best-effort until per-log
  sawmill hooks are confirmed against a live dump.

CREDITS AND LICENSE
- RE-UE4SS by the UE4SS-RE contributors: https://github.com/UE4SS-RE/RE-UE4SS
  (MIT License, original license at ue4ss\LICENSE).
- Lumber Vision by Kaliraxa (Nexus Mods).
- LogShare: original co-op ownership-split mod for this package.
- This merged package is unofficial and is not affiliated with the game
  developer, publisher, Nexus Mods, or the UE4SS-RE project.
- Generative AI assisted Lua development of Lumber Vision (per its author's
  disclosure) and of LogShare.
