LUMBER VISION v0.3.2
A Game About Chopping Trees

ABOUT
Lumber Vision adds a standalone purchasable perk to the Upgrades menu. Activate it to highlight chopped logs lying on the ground within the perk's current range.

FEATURES
- Three purchasable levels with increasing range and duration.
- Level 1: $500, 25 m, 4 seconds.
- Level 2: $1,500, 50 m, 7 seconds.
- Level 3: $3,000, 80 m, 12 seconds.
- No cooldown after the active duration ends.
- On-screen active timer and range.
- Native control hint that changes with the current input device.
- Activation sound and cyan pulse animation.
- Purchased levels persist with the game's save.
- Cached log tracking to reduce repeated world scans.

CONTROLS
- Keyboard: Q
- Controller: LT / Left Trigger

REQUIREMENTS
- A legal Steam copy of A Game About Chopping Trees.
- UE4SS v3.0.1 or a compatible newer build installed separately.

INSTALLATION
1. Install UE4SS in:
   A Game About Chopping Trees\ChoppingTrees\Binaries\Win64
2. Extract this archive into the same Win64 folder.
3. The final script path should be:
   Win64\ue4ss\Mods\LumberVision\Scripts\main.lua
4. Fully restart the game.

CONFIGURATION
Edit:
Win64\ue4ss\Mods\LumberVision\Scripts\LumberVisionConfig.lua

The config controls upgrade costs, range, duration, refresh rates, status display, control hint, activation sound, pulse opacity, pulse duration, and pulse color. Restart the game after editing it.

UNINSTALLATION
Delete:
Win64\ue4ss\Mods\LumberVision

Uninstalling does not delete or modify your save files. A previously purchased Lumber Vision level may remain as harmless save data and will become available again if the mod is reinstalled.

COMPATIBILITY
- Tested with game version 1.1.0.4.
- Client-side visual gameplay mod.
- Multiplayer has not been fully tested.

FILES
- Scripts\main.lua: core mod logic.
- Scripts\LumberVisionConfig.lua: user-editable settings.
- enabled.txt: enables the mod in UE4SS without replacing the user's mods.txt.

DISCLOSURE
Generative AI was used to assist with Lua development, debugging, and documentation. Apply the appropriate AI-Generated Content and AI Media tags when publishing this mod on Nexus Mods.

