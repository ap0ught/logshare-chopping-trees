LogShare v0.1.0 — A Game About Chopping Trees
Co-op log ownership split (UE4SS Lua mod)

WHAT IT DOES
- Tags each chopped log with the chopper's player id.
- On sale: seller == chopper -> full price.
- Seller ~= chopper -> seller keeps half, chopper gets the other half
  (fraction configurable: ChopperShare in LogShareConfig.lua).

REQUIREMENTS
- UE4SS installed in ChoppingTrees\Binaries\Win64 (dwmapi.dll + ue4ss\).
  The full package "ChoppingTrees-Mods-UE4SS-LumberVision-LogShare" includes it.
- Both co-op players should run the mod for consistent ownership tags/splits.

INSTALL
1. Extract this archive into ChoppingTrees\Binaries\Win64.
2. Confirm: Win64\ue4ss\Mods\LogShare\Scripts\main.lua
3. Fully restart the game.

CONFIGURE
Edit ue4ss\Mods\LogShare\Scripts\LogShareConfig.lua (ChopperShare, logging, toasts).
Restart after editing.

UNINSTALL
Delete ue4ss\Mods\LogShare. Does not touch save files.

NOTES
- v0.1.0 tags via BP_Tree_Log* spawn watchers and detects sales via Money
  attribute polling. Splits adjust each PlayerState's Money on this client;
  run on both clients so both sides stay consistent.
- Solo play is unaffected (seller always == chopper).
- Verbose logging is on by default; check the UE4SS console/log to verify splits.

CREDITS
- Built on RE-UE4SS (MIT): https://github.com/UE4SS-RE/RE-UE4SS
- Unofficial; not affiliated with the game developer or publisher.
- Generative AI assisted Lua development.
