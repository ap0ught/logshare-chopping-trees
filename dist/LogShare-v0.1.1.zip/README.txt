LogShare v0.1.1 — A Game About Chopping Trees
Co-op log ownership split (UE4SS Lua mod)

REQUIREMENTS
- UE4SS installed in ChoppingTrees\Binaries\Win64.

INSTALL
Extract into ChoppingTrees\Binaries\Win64, restart the game.

DEBUG (v0.1.1)
- On-screen status line: player, money, tag count, last event (LogShareConfig: DebugScreen).
- File log: LogShare.log (Win64 or Saved\Logs). Config: LogFile.
- UE4SS GUI console: Ctrl+O (ConsoleEnabled in UE4SS-settings.ini).

CONFIG
ue4ss\Mods\LogShare\Scripts\LogShareConfig.lua — restart after edit.
